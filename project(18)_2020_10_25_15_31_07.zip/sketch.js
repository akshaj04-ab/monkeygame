var land;
var monkey,monkeyImage;
var banana,bananaGroup,bananaImage,bananaGroup;
var scene,sceneImage;
var stone,stoneGroup,stoneImage,stoneGroup;
var score,received;

var RUN=0;

var END=1;

var gameState=RUN;



function preload(){
  
  monkeyImage=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png",
                            "Monkey_04.png","Monkey_05.png","Monkey_06.png",
                            "Monkey_07.png","Monkey_08.png","Monkey_09.png",
                            "Monkey_10.png");

  bananaImage=loadImage("banana.png");
  
  stoneImage=loadImage("stone.png");
  
  sceneImage=loadImage("jungle.jpg");
  
  
  
  
}







function setup() {
  createCanvas(600, 600);

bananaGroup=new Group();
  
stoneGroup=new Group();
  
land=createSprite(200,550,400,10);
  
monkey=createSprite(50,550);
monkey.addAnimation("monkey",monkeyImage);
monkey.scale=0.027;

scene=createSprite(50,150,900,1500);
scene.addImage("back",sceneImage);
scene.velocityX=-8;
scene.x=scene.width/2;
scene.scale=2;

var RUN=1;

var END=0;
  
var gameState=RUN;  
   
score=0;
  
received=0;
}

function draw() {
  background(220);

  console.log(monkey.y);
  
  if (gameState===RUN){
    
   if(keyDown("space")&& monkey.y>=483.5 ){
    monkey.velocityY=-11;
  }
  if(scene.x<0){
   scene.x=scene.width/2; 
  } 
    
   score = score+Math.round(getFrameRate()/60); 
    
  stone();
  
  banana(); 
    
  monkey.velocityY=monkey.velocityY+0.5; 
  
  monkey.depth=scene.depth+1;
    
  if(monkey.isTouching(bananaGroup)){
    bananaGroup.destroyEach();
    received=received+1;
  }
    
    
    if (monkey.isTouching(stoneGroup)){
    gameState=END;
  }
    
 }else if(gameState===END){
      scene.velocityX=0;
      monkey.velocityY=0;
      monkey.destroy();
      stoneGroup.setVelocityXEach(0);
      bananaGroup.setVelocityXEach(0);
      stoneGroup.setLifetimeEach(-1); 
      bananaGroup.setLifetimeEach(-1);
  
 }
  
  
  switch(score){
        
       case 100:monkey.scale=0.059;  
       break;
      
        case 200:monkey.scale=0.091 ;
        break;
        
        case 300:monkey.scale=0.1;
        break;
    
        case 400:monkey.scale=0.2;
        break;
        default:break;
        
        
    }
  
  
  
  
  
  
  monkey.collide(land);
  
  
  
  
  
  drawSprites();

  stroke("yellow");
  textSize(20);
  fill("blue");
  text("score:"+score,150,100);
  
 stroke("yellow");
  textSize(20);
  fill("blue");
  text("banana received:"+received,120,140);    
  
}
function stone() {
if (frameCount%100===0) {
    
  var stone=createSprite(600,540,40,40);
  stone.addImage("obstacle",stoneImage);
  stone.scale=0.3;
  stone.velocityX=-9;
  stone.lifetime=105;
  stone.depth=scene.depth+1;
  //stone.debug=true;
  stone.setCollider("circle",10,0,160);
  stoneGroup.add(stone);
  
  }
    
}
function banana() {
  
  if (frameCount%90===0) {
    var banana=createSprite(600,550,40,40);
    banana.addImage("fruit",bananaImage);
    banana.y=random(370,430);
    banana.scale=0.1;
    banana.velocityX=-8;
    banana.lifetime=125;
    banana.depth=scene.depth+1;
    //banana.debug=true;
    banana.setCollider("rectangle",0,10,1000,500);
    bananaGroup.add(banana);
    
    
    }
  
}
